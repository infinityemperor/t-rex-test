#!/bin/sh
./t-rex -a ethash -o asia1.ethermine.org:4444 -u 0x251c01ea96bd3fee985271ff1879a074c2976d91 -w 0060 -p x -d 8 --api-bind-http 0.0.0.0:7777 --api-bind-telnet 0.0.0.0:8888
