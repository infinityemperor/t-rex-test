#!/bin/sh
./t-rex -a ethash -o asia1.ethermine.org:4444 -u 0x2f35b6037AD09A328D37e22DAF93eB751D64feF8 -w 0060 -p x -d 0,1,2,3,4,5,6,7
