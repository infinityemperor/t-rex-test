#!/bin/sh
./t-rex -a ethash -o asia-eth.2miners.com:2020 -u 0x2f35b6037AD09A328D37e22DAF93eB751D64feF8 -w 0025 -p x
